create index IX_E8F5F6A0 on Teacher_Teacher (firstName[$COLUMN_LENGTH:75$]);
create index IX_B49117FF on Teacher_Teacher (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_32D9241 on Teacher_Teacher (uuid_[$COLUMN_LENGTH:75$], groupId);