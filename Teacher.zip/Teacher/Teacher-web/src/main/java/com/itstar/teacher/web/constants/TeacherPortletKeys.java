package com.itstar.teacher.web.constants;

/**
 * @author Manish Ku yadav
 */
public class TeacherPortletKeys {

	public static final String TEACHER =
		"com_itstar_teacher_web_TeacherPortlet";

}