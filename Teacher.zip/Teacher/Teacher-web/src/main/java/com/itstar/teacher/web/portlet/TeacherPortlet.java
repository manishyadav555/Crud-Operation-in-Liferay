package com.itstar.teacher.web.portlet;

import com.itstar.teacher.model.Teacher;
import com.itstar.teacher.service.TeacherLocalService;
import com.itstar.teacher.web.constants.TeacherPortletKeys;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author Manish Ku yadav
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Teacher",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + TeacherPortletKeys.TEACHER,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class TeacherPortlet extends MVCPortlet {
	private Log log = LogFactoryUtil.getLog(this.getClass().getName());

	@Reference
	CounterLocalService counterLocalService;
	@Reference
	TeacherLocalService teacherLocalService;

	@ProcessAction(name = "addTeacher")
	public void addTeacher(ActionRequest actionRequest,ActionResponse actionResponse) {
		long teacherId = counterLocalService.increment(Teacher.class.getName());
		String enrollmentNo = ParamUtil.getString(actionRequest, "enrollmentNo");
		String firstName = ParamUtil.getString(actionRequest, "firstName");
		String lastName = ParamUtil.getString(actionRequest, "lastName");
		String contactNo = ParamUtil.getString(actionRequest, "contactNo");
		String city = ParamUtil.getString(actionRequest, "city");

		Teacher teacher = teacherLocalService.createTeacher(teacherId);
		teacher.setTeacherId(teacherId);
		teacher.setEnrollmentNo(enrollmentNo);
		teacher.setFirstName(firstName);
		teacher.setLastName(lastName);
		teacher.setContactNo(contactNo);
		teacher.setCity(city);

		teacherLocalService.addTeacher(teacher);
	}
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse) throws IOException, PortletException{
		List<Teacher> teacherList = teacherLocalService.getTeachers(QueryUtil.ALL_POS, QueryUtil.ALL_POS);
		renderRequest.setAttribute("teacherList", teacherList);
		super.render(renderRequest, renderResponse);
	}
	
	@ProcessAction(name = "updateTeacher")
    public void updateTeacher(ActionRequest actionRequest,  ActionResponse actionResponse) {
        long teacherId = ParamUtil.getLong(actionRequest,"teacherId", GetterUtil.DEFAULT_LONG);
        String enrollmentNo = ParamUtil.getString(actionRequest, "enrollmentNo", GetterUtil.DEFAULT_STRING);
        String firstName = ParamUtil.getString(actionRequest, "firstName", GetterUtil.DEFAULT_STRING);
        String lastName = ParamUtil.getString(actionRequest, "lastName", GetterUtil.DEFAULT_STRING);
        String contactNo = ParamUtil.getString(actionRequest, "contactNo", GetterUtil.DEFAULT_STRING);
        String city = ParamUtil.getString(actionRequest, "city", GetterUtil.DEFAULT_STRING);

        Teacher teacher = null;
        try {
            teacher = teacherLocalService.getTeacher(teacherId);
        } catch (Exception e) {
            log.error(e.getCause(), e);
        }

        if(Validator.isNotNull(teacher)) {
            teacher.setEnrollmentNo(enrollmentNo);
            teacher.setFirstName(firstName);
            teacher.setLastName(lastName);
            teacher.setContactNo(contactNo);
            teacher.setCity(city);
            teacherLocalService.updateTeacher(teacher);
        }
    }
 	@ProcessAction(name = "deleteTeacher")
    public void deleteTeacher(ActionRequest actionRequest, ActionResponse actionResponse){
        long teacherId = ParamUtil.getLong(actionRequest, "teacherId", GetterUtil.DEFAULT_LONG);
        try {
            teacherLocalService.deleteTeacher(teacherId);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
	
}

	
